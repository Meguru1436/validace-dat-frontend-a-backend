const express = require('express');
const app = express();
const path = require('path');
const port = 3000;

app.use(express.json());

app.use(express.static(path.join(__dirname, 'public')));

const users = {
    usernames: ['existingUser1', 'existingUser2'],
    emails: ['existing@example.com', 'another@example.com']
};

function validatePassword(password) {
    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,16}$/;
    return passwordRegex.test(password);
}

function validateEmail(email) {
    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    return emailRegex.test(email);
}

app.post('/register', (req, res) => {
    const { username, email, password } = req.body;
    const errors = {};

    if (!/^[a-zA-Z0-9]+$/.test(username)) {
        errors.username = 'Uživatelské jméno může obsahovat pouze alfanumerické znaky.';
    } else if (users.usernames.includes(username)) {
        errors.username = 'Toto uživatelské jméno již existuje.';
    }

    if (!validateEmail(email)) {
        errors.email = 'Email není ve správném formátu.';
    } else if (users.emails.includes(email)) {
        errors.email = 'Tento email již je zaregistrovaný.';
    }

    if (!validatePassword(password)) {
        errors.password = 'Heslo musí mít alespoň 8 znaků a obsahovat malé a velké písmeno, číslo a speciální znak.';
    }

    if (Object.keys(errors).length > 0) {
        return res.json({ success: false, errors });
    }

    users.usernames.push(username);
    users.emails.push(email);
    res.json({ success: true });
});

app.listen(port, () => {
    console.log(`http://localhost:${port}`);
});
