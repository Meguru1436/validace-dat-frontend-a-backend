document.getElementById('registerForm').addEventListener('submit', function(event) {
    event.preventDefault();
    
    // Clear any previous error alerts
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    let valid = true;

    const usernameRegex = /^[a-zA-Z0-9]+$/;
    if (!usernameRegex.test(username)) {
        alert('Uživatelské jméno může obsahovat pouze alfanumerické znaky.');
        valid = false;
    }

    const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    if (!emailRegex.test(email)) {
        alert('Email není ve správném formátu.');
        valid = false;
    }

    const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,16}$/;
    if (!passwordRegex.test(password)) {
        alert('Heslo musí mít alespoň 8 znaků a obsahovat malé a velké písmeno, číslo a speciální znak.');
        valid = false;
    }

    if (valid) {
        fetch('/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        })
        .then(response => response.json())
        .then(data => {
            if (data.success) {
                alert('Registrace byla úspěšná');
            } else {
                if (data.errors.username) {
                    alert(data.errors.username);
                }
                if (data.errors.email) {
                    alert(data.errors.email);
                }
                if (data.errors.password) {
                    alert(data.errors.password);
                }
            }
        })
        .catch(error => console.error('Chyba při registraci:', error));
    }
});
